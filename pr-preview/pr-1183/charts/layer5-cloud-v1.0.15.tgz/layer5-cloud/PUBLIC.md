This folder is PUBLIC and can be viewed by anyone.
Helm Charts and all of its contentst are publicly available.